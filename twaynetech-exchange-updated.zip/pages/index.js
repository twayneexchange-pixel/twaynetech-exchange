'use client';

import { useEffect, useState } from 'react';
import { db, auth } from '../firebase';
import { doc, getDoc, setDoc } from 'firebase/firestore';
import { onAuthStateChanged } from 'firebase/auth';
import axios from 'axios';

export default function Dashboard() {
  const [wallet, setWallet] = useState({ BTC: 0, ETH: 0, USDT: 0 });
  const [uid, setUid] = useState('');
  const [prices, setPrices] = useState({});
  const [amountNGN, setAmountNGN] = useState('');
  const [email, setEmail] = useState('');
  const [payLink, setPayLink] = useState('');

  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, async (user) => {
      if (user) {
        setUid(user.uid);
        setEmail(user.email);
        const walletRef = doc(db, 'wallets', user.uid);
        const walletSnap = await getDoc(walletRef);
        if (walletSnap.exists()) {
          setWallet(walletSnap.data());
        } else {
          await setDoc(walletRef, { BTC: 0, ETH: 0, USDT: 0 });
        }
      }
    });
    return () => unsubscribe();
  }, []);

  useEffect(() => {
    const fetchPrices = async () => {
      const res = await axios.get(
        'https://api.coingecko.com/api/v3/simple/price?ids=bitcoin,ethereum,tether&vs_currencies=usd'
      );
      setPrices(res.data);
    };
    fetchPrices();
  }, []);

  const handlePaystack = async () => {
    try {
      const res = await axios.post('/api/paystack-initiate', {
        email,
        amount: Number(amountNGN) * 100,
      });
      setPayLink(res.data.authorization_url);
    } catch (error) {
      console.error('Payment initiation failed:', error);
    }
  };

  return (
    <div className="min-h-screen bg-gray-900 text-white p-6">
      <h1 className="text-3xl font-bold mb-6">Twaynetech Exchange</h1>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-8">
        {Object.entries(prices).map(([coin, data]) => (
          <div key={coin} className="bg-gray-800 p-4 rounded-xl">
            <h2 className="text-xl capitalize font-semibold">{coin}</h2>
            <p className="text-green-400 text-lg mt-1">${data.usd}</p>
            <p className="text-sm text-gray-300">You own: {wallet[coin.toUpperCase()]}</p>
          </div>
        ))}
      </div>

      <div className="bg-gray-800 p-6 rounded-2xl max-w-xl mx-auto">
        <h2 className="text-xl mb-4 font-semibold">Fund Wallet (NGN)</h2>
        <input
          type="number"
          placeholder="Amount in Naira"
          value={amountNGN}
          onChange={(e) => setAmountNGN(e.target.value)}
          className="w-full p-2 bg-gray-700 text-white rounded mb-4"
        />
        <button
          onClick={handlePaystack}
          className="w-full bg-gradient-to-r from-green-500 to-blue-600 py-2 rounded-xl hover:opacity-90"
        >
          Proceed to Pay
        </button>
        {payLink && (
          <a
            href={payLink}
            target="_blank"
            rel="noopener noreferrer"
            className="block text-blue-400 text-sm mt-4 underline"
          >
            Click here to complete payment
          </a>
        )}
      </div>

      <link rel="manifest" href="/manifest.json" />
      <meta name="theme-color" content="#111827" />
      <meta name="apple-mobile-web-app-capable" content="yes" />
      <meta name="apple-mobile-web-app-status-bar-style" content="black-translucent" />
      <meta name="apple-mobile-web-app-title" content="Twaynetech Exchange" />
      <link rel="apple-touch-icon" href="/icons/icon-192x192.png" />
    </div>
  );
}
